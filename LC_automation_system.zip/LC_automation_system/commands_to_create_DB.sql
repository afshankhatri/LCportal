use lcsystem;
desc user;
select * from user;


-- studets table
CREATE TABLE students (
    sr_no INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,  -- Links to users.id
    GR_no VARCHAR(100) UNIQUE,
    yearOfJoin YEAR,  -- Changed from DATE to YEAR
    courseName VARCHAR(255),
    reasonOfLeaving VARCHAR(255),
    PRN VARCHAR(255),
    UPRN VARCHAR(255),
    isSubmitted INT,
    semester INT,
    lastLogin TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    finalYearMarksheet VARCHAR(255),
    declaration INT,
    FOREIGN KEY (user_id) REFERENCES user(Sr_No) ON DELETE CASCADE
);

DELIMITER //

CREATE TRIGGER after_user_insert
AFTER INSERT ON user
FOR EACH ROW
BEGIN
    IF NEW.user_type = 0 THEN
        INSERT INTO students (user_id)
        VALUES (NEW.Sr_No);
    END IF;
END;

//
DELIMITER ;

select * from students





